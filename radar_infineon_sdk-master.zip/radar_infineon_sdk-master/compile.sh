#!/bin/bash

scons .

